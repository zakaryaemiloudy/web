package com.bks.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DonRequest {
    @NotNull(message = "L'ID de l'hôpital est obligatoire")
    private Long hopitalId;

    @Min(value = 350, message = "Quantité minimale : 350 ml")
    @Max(value = 500, message = "Quantité maximale : 500 ml")
    private Integer quantiteMl = 450;

    private String notes;
}
