package com.bks.config;

import com.bks.enums.*;
import com.bks.model.*;
import com.bks.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Initializes the database with sample data on application startup.
 * Only creates data that doesn't already exist.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UtilisateurRepository utilisateurRepository;
    private final HopitalRepository hopitalRepository;
    private final DonneurRepository donneurRepository;
    private final StockSangRepository stockSangRepository;
    private final BadgeRepository badgeRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) {
        log.info("🚀 Vérification et initialisation des données de démonstration...");

        boolean badgesCreated = initBadges();
        boolean hopitauxCreated = initHopitaux();
        boolean superAdminCreated = initSuperAdmin();
        boolean adminsCreated = initAdmins();
        boolean usersCreated = initUsers();
        initDonneurs();
        initStocks();

        if (!badgesCreated && !hopitauxCreated && !superAdminCreated && !adminsCreated && !usersCreated) {
            log.info("📦 Données de démonstration déjà présentes.");
            return;
        }

        log.info("✅ Initialisation terminée avec succès!");
        log.info("📧 Comptes disponibles:");
        log.info("   - Super Admin: superadmin@bks.com / admin123");
        log.info("   - Admin CHU Casablanca: admin.casa@bks.com / admin123");
        log.info("   - Admin CHU Rabat: admin.rabat@bks.com / admin123");
        log.info("   - Donneur: donneur1@test.com / user123");
    }

    private boolean initBadges() {
        if (badgeRepository.count() > 0) {
            return false;
        }
        
        log.info("🏅 Création des badges...");

        List<Badge> badges = List.of(
            createBadge("Premier Don", "Félicitations pour votre premier don!", NiveauBadge.BRONZE, 1, 10),
            createBadge("Donneur Régulier", "5 dons effectués", NiveauBadge.ARGENT, 5, 50),
            createBadge("Donneur Fidèle", "10 dons effectués", NiveauBadge.OR, 10, 100),
            createBadge("Donneur Expert", "25 dons effectués", NiveauBadge.PLATINE, 25, 250),
            createBadge("Héros du Sang", "50 dons effectués", NiveauBadge.DIAMANT, 50, 500),
            createBadge("Légende", "100 dons effectués", NiveauBadge.LEGENDE, 100, 1000),
            createBadge("Champion de Vie", "Donneur d'exception", NiveauBadge.CHAMPION, 150, 2000)
        );

        badgeRepository.saveAll(badges);
        return true;
    }

    private Badge createBadge(String nom, String description, NiveauBadge niveau, int donsRequis, int points) {
        Badge badge = new Badge();
        badge.setNom(nom);
        badge.setDescription(description);
        badge.setNiveau(niveau);
        badge.setNombreDonsRequis(donsRequis);
        badge.setPointsAttribues(points);
        badge.setActif(true);
        badge.setConditionObtention(donsRequis + " dons effectués");
        return badge;
    }

    private boolean initHopitaux() {
        if (hopitalRepository.count() > 0) {
            return false;
        }
        
        log.info("🏥 Création des hôpitaux...");

        Hopital chu1 = new Hopital();
        chu1.setNom("CHU Ibn Rochd Casablanca");
        chu1.setAdresse("Quartier des Hôpitaux");
        chu1.setVille("Casablanca");
        chu1.setRegion("Casablanca-Settat");
        chu1.setTelephone("0522222222");
        chu1.setEmail("contact@chu-casablanca.ma");
        chu1.setStatut(StatutHopital.VALIDE);
        chu1.setCapaciteStockage(10000);
        chu1.setCertifie(true);
        chu1.setDescription("Centre Hospitalier Universitaire Ibn Rochd de Casablanca");
        chu1.setDateValidation(LocalDateTime.now());

        Hopital chu2 = new Hopital();
        chu2.setNom("CHU Ibn Sina Rabat");
        chu2.setAdresse("Avenue Ibn Sina");
        chu2.setVille("Rabat");
        chu2.setRegion("Rabat-Salé-Kénitra");
        chu2.setTelephone("0537777777");
        chu2.setEmail("contact@chu-rabat.ma");
        chu2.setStatut(StatutHopital.VALIDE);
        chu2.setCapaciteStockage(8000);
        chu2.setCertifie(true);
        chu2.setDescription("Centre Hospitalier Universitaire Ibn Sina de Rabat");
        chu2.setDateValidation(LocalDateTime.now());

        Hopital hopital3 = new Hopital();
        hopital3.setNom("Hôpital Régional Marrakech");
        hopital3.setAdresse("Avenue Mohammed VI");
        hopital3.setVille("Marrakech");
        hopital3.setRegion("Marrakech-Safi");
        hopital3.setTelephone("0524444444");
        hopital3.setEmail("contact@hopital-marrakech.ma");
        hopital3.setStatut(StatutHopital.VALIDE);
        hopital3.setCapaciteStockage(5000);
        hopital3.setCertifie(false);
        hopital3.setDescription("Hôpital Régional de Marrakech");
        hopital3.setDateValidation(LocalDateTime.now());

        Hopital hopital4 = new Hopital();
        hopital4.setNom("Clinique Privée Tanger");
        hopital4.setAdresse("Boulevard Pasteur");
        hopital4.setVille("Tanger");
        hopital4.setRegion("Tanger-Tétouan-Al Hoceïma");
        hopital4.setTelephone("0539333333");
        hopital4.setEmail("contact@clinique-tanger.ma");
        hopital4.setStatut(StatutHopital.EN_ATTENTE);
        hopital4.setCapaciteStockage(3000);
        hopital4.setDescription("Clinique privée en attente de validation");

        hopitalRepository.saveAll(List.of(chu1, chu2, hopital3, hopital4));
        return true;
    }

    private boolean initSuperAdmin() {
        if (utilisateurRepository.findByEmail("superadmin@bks.com").isPresent()) {
            return false;
        }
        
        log.info("👑 Création du Super Admin...");

        Utilisateur superAdmin = new Utilisateur();
        superAdmin.setEmail("superadmin@bks.com");
        superAdmin.setMotDePasse(passwordEncoder.encode("admin123"));
        superAdmin.setNom("Administrateur");
        superAdmin.setPrenom("Super");
        superAdmin.setTelephone("0600000000");
        superAdmin.setRole(Role.SUPER_ADMIN);
        superAdmin.setActif(true);
        superAdmin.setDateCreation(LocalDateTime.now());

        utilisateurRepository.save(superAdmin);
        return true;
    }

    private boolean initAdmins() {
        boolean created = false;
        List<Hopital> hopitaux = hopitalRepository.findAll();
        
        if (hopitaux.isEmpty()) {
            return false;
        }

        if (utilisateurRepository.findByEmail("admin.casa@bks.com").isEmpty()) {
            log.info("👤 Création admin CHU Casablanca...");
            Utilisateur admin1 = new Utilisateur();
            admin1.setEmail("admin.casa@bks.com");
            admin1.setMotDePasse(passwordEncoder.encode("admin123"));
            admin1.setNom("Benali");
            admin1.setPrenom("Ahmed");
            admin1.setTelephone("0611111111");
            admin1.setRole(Role.ADMIN);
            admin1.setHopital(hopitaux.stream().filter(h -> h.getNom().contains("Casablanca")).findFirst().orElse(hopitaux.get(0)));
            admin1.setActif(true);
            admin1.setDateCreation(LocalDateTime.now());
            utilisateurRepository.save(admin1);
            created = true;
        }

        if (utilisateurRepository.findByEmail("admin.rabat@bks.com").isEmpty()) {
            log.info("👤 Création admin CHU Rabat...");
            Utilisateur admin2 = new Utilisateur();
            admin2.setEmail("admin.rabat@bks.com");
            admin2.setMotDePasse(passwordEncoder.encode("admin123"));
            admin2.setNom("El Amrani");
            admin2.setPrenom("Fatima");
            admin2.setTelephone("0622222222");
            admin2.setRole(Role.ADMIN);
            admin2.setHopital(hopitaux.stream().filter(h -> h.getNom().contains("Rabat")).findFirst().orElse(hopitaux.get(0)));
            admin2.setActif(true);
            admin2.setDateCreation(LocalDateTime.now());
            utilisateurRepository.save(admin2);
            created = true;
        }

        if (utilisateurRepository.findByEmail("admin.marrakech@bks.com").isEmpty()) {
            log.info("👤 Création admin Marrakech...");
            Utilisateur admin3 = new Utilisateur();
            admin3.setEmail("admin.marrakech@bks.com");
            admin3.setMotDePasse(passwordEncoder.encode("admin123"));
            admin3.setNom("Saidi");
            admin3.setPrenom("Youssef");
            admin3.setTelephone("0633333333");
            admin3.setRole(Role.ADMIN);
            admin3.setHopital(hopitaux.stream().filter(h -> h.getNom().contains("Marrakech")).findFirst().orElse(hopitaux.get(0)));
            admin3.setActif(true);
            admin3.setDateCreation(LocalDateTime.now());
            utilisateurRepository.save(admin3);
            created = true;
        }

        return created;
    }

    private boolean initUsers() {
        boolean created = false;
        
        String[][] usersData = {
            {"donneur1@test.com", "Martin", "Pierre", "0644444444", "150"},
            {"donneur2@test.com", "Alaoui", "Khadija", "0655555555", "75"},
            {"donneur3@test.com", "Tazi", "Omar", "0666666666", "300"},
            {"donneur4@test.com", "Berrada", "Salma", "0677777777", "50"}
        };

        for (String[] data : usersData) {
            if (utilisateurRepository.findByEmail(data[0]).isEmpty()) {
                log.info("👥 Création utilisateur {}...", data[0]);
                Utilisateur user = new Utilisateur();
                user.setEmail(data[0]);
                user.setMotDePasse(passwordEncoder.encode("user123"));
                user.setNom(data[1]);
                user.setPrenom(data[2]);
                user.setTelephone(data[3]);
                user.setRole(Role.USER);
                user.setActif(true);
                user.setPointsTotal(Integer.parseInt(data[4]));
                user.setDateCreation(LocalDateTime.now());
                utilisateurRepository.save(user);
                created = true;
            }
        }

        return created;
    }

    private void initDonneurs() {
        Object[][] donneursData = {
            {"donneur1@test.com", "AB123456", LocalDate.of(1990, 5, 15), GroupeSanguin.O_POSITIF, Sexe.HOMME, "123 Rue Hassan II", "Casablanca", 75.0, 3},
            {"donneur2@test.com", "CD789012", LocalDate.of(1988, 8, 22), GroupeSanguin.A_POSITIF, Sexe.FEMME, "456 Avenue Mohammed V", "Rabat", 62.0, 2},
            {"donneur3@test.com", "EF345678", LocalDate.of(1985, 3, 10), GroupeSanguin.B_NEGATIF, Sexe.HOMME, "789 Boulevard Zerktouni", "Casablanca", 82.0, 8},
            {"donneur4@test.com", "GH901234", LocalDate.of(1995, 11, 28), GroupeSanguin.AB_POSITIF, Sexe.FEMME, "321 Rue Ibn Batouta", "Marrakech", 58.0, 1}
        };

        for (Object[] data : donneursData) {
            String email = (String) data[0];
            String cin = (String) data[1];
            
            Optional<Utilisateur> userOpt = utilisateurRepository.findByEmail(email);
            if (userOpt.isEmpty()) continue;
            
            Utilisateur user = userOpt.get();
            if (donneurRepository.findByUtilisateur(user).isPresent()) continue;
            
            log.info("🩸 Création profil donneur pour {}...", email);
            
            Donneur donneur = new Donneur();
            donneur.setUtilisateur(user);
            donneur.setCin(cin);
            donneur.setDateNaissance((LocalDate) data[2]);
            donneur.setGroupeSanguin((GroupeSanguin) data[3]);
            donneur.setSexe((Sexe) data[4]);
            donneur.setAdresse((String) data[5]);
            donneur.setVille((String) data[6]);
            donneur.setPoids((Double) data[7]);
            donneur.setEligible(true);
            donneur.setNombreDonsTotal((Integer) data[8]);
            donneur.setDateDernierDon(LocalDate.now().minusMonths(4));
            donneur.setDateProchaineEligibilite(LocalDate.now().minusMonths(1));
            donneur.setAntecedentsMedicaux("Aucun");
            
            donneurRepository.save(donneur);
        }
    }

    private void initStocks() {
        List<Hopital> hopitaux = hopitalRepository.findAll().stream()
            .filter(h -> h.getStatut() == StatutHopital.VALIDE)
            .toList();

        for (Hopital hopital : hopitaux) {
            for (GroupeSanguin groupe : GroupeSanguin.values()) {
                if (stockSangRepository.findByHopitalAndGroupeSanguin(hopital, groupe).isPresent()) {
                    continue;
                }
                
                log.info("📊 Création stock {} pour {}...", groupe, hopital.getNom());
                
                StockSang stock = new StockSang();
                stock.setHopital(hopital);
                stock.setGroupeSanguin(groupe);

                int baseQuantity = switch (groupe) {
                    case O_POSITIF -> 8000;
                    case A_POSITIF -> 6000;
                    case B_POSITIF -> 4000;
                    case AB_POSITIF -> 2000;
                    case O_NEGATIF -> 3000;
                    case A_NEGATIF -> 2500;
                    case B_NEGATIF -> 1500;
                    case AB_NEGATIF -> 800;
                };

                int hopitalIndex = hopitaux.indexOf(hopital);
                int quantity = (int) (baseQuantity * (0.7 + (hopitalIndex * 0.15)));
                stock.setQuantiteDisponible(quantity);
                stock.setNombrePoches(quantity / 450);
                stock.setDerniereMiseAJour(LocalDateTime.now());
                stock.calculerNiveauStock();

                stockSangRepository.save(stock);
            }
        }
    }
}
