
// ========== PatientController.java ==========
package com.bks.controller;

import com.bks.dto.*;
import com.bks.service.*;
import com.bks.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/patient")
@PreAuthorize("hasAnyRole('USER', 'ADMIN', 'SUPER_ADMIN')")
public class PatientController {

    @Autowired
    private DemandeSangService demandeService;

    @Autowired
    private StockService stockService;

    @Autowired
    private DemandeSangRepository demandeRepository;

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    // ===== DEMANDES DE SANG =====

    @PostMapping("/demandes")
    public ResponseEntity<DemandeSangResponse> creerDemande(
            @Valid @RequestBody DemandeSangRequest request,
            Authentication auth) {
        var user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(demandeService.creerDemande(user.getId(), request));
    }

    @GetMapping("/demandes")
    public ResponseEntity<List<DemandeSangResponse>> getMesDemandes(Authentication auth) {
        var user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(
                demandeRepository.findByPatientId(user.getId()).stream()
                        .map(d -> {
                            DemandeSangResponse r = new DemandeSangResponse();
                            r.setId(d.getId());
                            r.setGroupeSanguinDemande(d.getGroupeSanguinDemande());
                            r.setQuantiteDemandee(d.getQuantiteDemandee());
                            r.setStatut(d.getStatut());
                            r.setUrgence(d.getUrgence());
                            r.setDateDemande(d.getDateDemande());
                            r.setHopitalNom(d.getHopital().getNom());
                            return r;
                        })
                        .toList()
        );
    }

    @GetMapping("/demandes/{id}")
    public ResponseEntity<DemandeSangResponse> getDetailsDemande(@PathVariable Long id) {
        var demande = demandeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Demande non trouvée"));

        DemandeSangResponse response = new DemandeSangResponse();
        response.setId(demande.getId());
        response.setGroupeSanguinDemande(demande.getGroupeSanguinDemande());
        response.setQuantiteDemandee(demande.getQuantiteDemandee());
        response.setStatut(demande.getStatut());
        response.setUrgence(demande.getUrgence());
        response.setDateDemande(demande.getDateDemande());
        response.setHopitalNom(demande.getHopital().getNom());
        response.setNomPatient(demande.getNomPatient());
        response.setPrenomPatient(demande.getPrenomPatient());

        return ResponseEntity.ok(response);
    }

    // ===== CONSULTATION STOCKS =====

    @GetMapping("/stocks/{hopitalId}")
    public ResponseEntity<List<StockResponse>> consulterStocks(@PathVariable Long hopitalId) {
        return ResponseEntity.ok(stockService.getStockParHopital(hopitalId));
    }
}
