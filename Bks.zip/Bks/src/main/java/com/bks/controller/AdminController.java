package com.bks.controller;

import com.bks.dto.*;
import com.bks.enums.StatutDemande;
import com.bks.enums.StatutDon;
import com.bks.model.*;
import com.bks.service.*;
import com.bks.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN')")
public class AdminController {

    @Autowired
    private DonneurService donneurService;

    @Autowired
    private DemandeSangService demandeService;

    @Autowired
    private StockService stockService;

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private CampagneService campagneService;

    @Autowired
    private DonRepository donRepository;

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    @Autowired
    private GamificationService gamificationService;

    // ===== DASHBOARD =====

    @GetMapping("/dashboard")
    public ResponseEntity<DashboardAnalytics> getDashboard(Authentication auth) {
        Utilisateur admin = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        if (admin.getHopital() == null) {
            throw new RuntimeException("Admin non associé à un hôpital");
        }

        return ResponseEntity.ok(dashboardService.getDashboardAdmin(admin.getHopital().getId()));
    }

    // ===== GESTION DONS =====

    @GetMapping("/dons")
    public ResponseEntity<List<Don>> getDons(Authentication auth) {
        Utilisateur admin = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(donRepository.findByHopitalId(admin.getHopital().getId()));
    }

    @PutMapping("/dons/{id}/valider")
    public ResponseEntity<Don> validerDon(
            @PathVariable Long id,
            Authentication auth) {
        Utilisateur admin = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        Don don = donRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Don non trouvé"));

        don.setStatut(StatutDon.VALIDE);
        don.setValideParId(admin.getId());
        don.setDateValidation(LocalDateTime.now());
        don.setDatePeremption(LocalDateTime.now().plusDays(42));
        don.setNumeroPoche("POCHE-" + System.currentTimeMillis());

        don = donRepository.save(don);

        // Ajouter au stock
        stockService.ajouterStock(
                don.getHopital().getId(),
                don.getDonneur().getGroupeSanguin(),
                don.getQuantiteMl()
        );

        // Attribuer points et badges
        gamificationService.attribuerPoints(don.getDonneur().getId(), 10);
        gamificationService.verifierEtAttribuerBadges(don.getDonneur().getId());

        return ResponseEntity.ok(don);
    }

    @PutMapping("/dons/{id}/rejeter")
    public ResponseEntity<Don> rejeterDon(@PathVariable Long id, @RequestBody String raison) {
        Don don = donRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Don non trouvé"));

        don.setStatut(StatutDon.REJETE);
        don.setNotes(raison);

        return ResponseEntity.ok(donRepository.save(don));
    }

    // ===== GESTION DEMANDES =====

    @GetMapping("/demandes")
    public ResponseEntity<List<DemandeSangResponse>> getDemandes(Authentication auth) {
        Utilisateur admin = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(demandeService.getDemandesParHopital(admin.getHopital().getId()));
    }

    @GetMapping("/demandes/urgentes")
    public ResponseEntity<List<DemandeSangResponse>> getDemandesUrgentes() {
        return ResponseEntity.ok(demandeService.getDemandesUrgentes());
    }

    @PutMapping("/demandes/{id}/traiter")
    public ResponseEntity<DemandeSangResponse> traiterDemande(
            @PathVariable Long id,
            @RequestParam StatutDemande statut,
            Authentication auth) {
        Utilisateur admin = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(demandeService.traiterDemande(id, admin.getId(), statut));
    }

    // ===== GESTION STOCKS =====

    @GetMapping("/stocks")
    public ResponseEntity<List<StockResponse>> getStocks(Authentication auth) {
        Utilisateur admin = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(stockService.getStockParHopital(admin.getHopital().getId()));
    }

    @GetMapping("/stocks/critiques")
    public ResponseEntity<List<StockResponse>> getStocksCritiques() {
        return ResponseEntity.ok(stockService.getStocksCritiques());
    }

    // ===== GESTION DONNEURS =====

    @GetMapping("/donneurs")
    public ResponseEntity<List<DonneurResponse>> getDonneurs() {
        return ResponseEntity.ok(donneurService.getDonneursEligibles());
    }

    @GetMapping("/donneurs/top")
    public ResponseEntity<List<DonneurResponse>> getTopDonneurs() {
        return ResponseEntity.ok(donneurService.getTopDonneurs(10));
    }

    // ===== CAMPAGNES =====

    @PostMapping("/campagnes")
    public ResponseEntity<CampagneResponse> creerCampagne(
            @Valid @RequestBody CampagneRequest request,
            Authentication auth) {
        Utilisateur admin = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        request.setHopitalId(admin.getHopital().getId());
        request.setNationale(false);

        return ResponseEntity.ok(campagneService.creerCampagne(admin.getId(), request));
    }

    @GetMapping("/campagnes/actives")
    public ResponseEntity<List<CampagneResponse>> getCampagnesActives() {
        return ResponseEntity.ok(campagneService.getCampagnesActives());
    }
}