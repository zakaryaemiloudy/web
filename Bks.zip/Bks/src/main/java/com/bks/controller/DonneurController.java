package com.bks.controller;

import com.bks.dto.*;
import com.bks.enums.StatutDon;
import com.bks.model.*;
import com.bks.service.*;
import com.bks.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/donneur")
@PreAuthorize("hasAnyRole('USER', 'ADMIN', 'SUPER_ADMIN')")
public class DonneurController {

    private final DonneurService donneurService;
    private final DonneurRepository donneurRepository;
    private final DonRepository donRepository;
    private final UtilisateurRepository utilisateurRepository;
    private final HopitalRepository hopitalRepository;
    private final GamificationService gamificationService;
    private final CampagneService campagneService;

    public DonneurController(DonneurService donneurService,
                             DonneurRepository donneurRepository,
                             DonRepository donRepository,
                             UtilisateurRepository utilisateurRepository,
                             HopitalRepository hopitalRepository,
                             GamificationService gamificationService,
                             CampagneService campagneService) {
        this.donneurService = donneurService;
        this.donneurRepository = donneurRepository;
        this.donRepository = donRepository;
        this.utilisateurRepository = utilisateurRepository;
        this.hopitalRepository = hopitalRepository;
        this.gamificationService = gamificationService;
        this.campagneService = campagneService;
    }

    // ===== PROFIL DONNEUR =====

    @PostMapping("/profil")
    public ResponseEntity<DonneurResponse> creerProfil(
            @Valid @RequestBody Donneur donneur,
            Authentication auth) {
        Utilisateur user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(donneurService.inscrireDonneur(user.getId(), donneur));
    }

    @GetMapping("/profil")
    public ResponseEntity<DonneurResponse> getProfil(Authentication auth) {
        Utilisateur user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(donneurService.getDonneurByUtilisateurId(user.getId()));
    }

    // ===== DONS =====

    @PostMapping("/dons")
    public ResponseEntity<Don> declarerDon(
            @Valid @RequestBody DonRequest request,
            Authentication auth) {
        Utilisateur user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        Donneur donneur = donneurRepository.findByUtilisateurId(user.getId())
                .orElseThrow(() -> new RuntimeException("Profil donneur non trouvé"));

        if (!donneur.getEligible()) {
            throw new RuntimeException("Vous n'êtes pas éligible pour donner actuellement");
        }

        Hopital hopital = hopitalRepository.findById(request.getHopitalId())
                .orElseThrow(() -> new RuntimeException("Hôpital non trouvé"));

        Don don = new Don();
        don.setDonneur(donneur);
        don.setHopital(hopital);
        don.setQuantiteMl(request.getQuantiteMl());
        don.setNotes(request.getNotes());
        don.setStatut(StatutDon.EN_ATTENTE);
        don.setDateDon(LocalDateTime.now());

        don = donRepository.save(don);

        return ResponseEntity.ok(don);
    }

    @GetMapping("/dons/historique")
    public ResponseEntity<List<Don>> getHistoriqueDons(Authentication auth) {
        Utilisateur user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        Donneur donneur = donneurRepository.findByUtilisateurId(user.getId())
                .orElseThrow(() -> new RuntimeException("Profil donneur non trouvé"));

        return ResponseEntity.ok(donRepository.findByDonneurId(donneur.getId()));
    }

    // ===== BADGES & GAMIFICATION =====

    @GetMapping("/badges")
    public ResponseEntity<List<BadgeResponse>> getMesBadges(Authentication auth) {
        Utilisateur user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        Donneur donneur = donneurRepository.findByUtilisateurId(user.getId())
                .orElseThrow(() -> new RuntimeException("Profil donneur non trouvé"));

        return ResponseEntity.ok(gamificationService.getBadgesDonneur(donneur.getId()));
    }

    @GetMapping("/points")
    public ResponseEntity<Integer> getMesPoints(Authentication auth) {
        Utilisateur user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        return ResponseEntity.ok(user.getPointsTotal());
    }

    @GetMapping("/classement")
    public ResponseEntity<List<DonneurResponse>> getClassement() {
        return ResponseEntity.ok(donneurService.getTopDonneurs(50));
    }

    // ===== CAMPAGNES =====

    @GetMapping("/campagnes")
    public ResponseEntity<List<CampagneResponse>> getCampagnesDisponibles() {
        return ResponseEntity.ok(campagneService.getCampagnesActives());
    }

    @PostMapping("/campagnes/{id}/participer")
    public ResponseEntity<CampagneResponse> participerCampagne(
            @PathVariable Long id,
            Authentication auth) {
        Utilisateur user = utilisateurRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        Donneur donneur = donneurRepository.findByUtilisateurId(user.getId())
                .orElseThrow(() -> new RuntimeException("Profil donneur non trouvé"));

        return ResponseEntity.ok(campagneService.participerCampagne(id, donneur.getId()));
    }
}