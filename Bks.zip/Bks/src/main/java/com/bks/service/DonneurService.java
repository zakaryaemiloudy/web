package com.bks.service;

import com.bks.dto.*;
import com.bks.enums.NiveauBadge;
import com.bks.model.*;
import com.bks.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DonneurService {

    @Autowired
    private DonneurRepository donneurRepository;

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    @Autowired
    private DonneurBadgeRepository donneurBadgeRepository;

    @Transactional
    public DonneurResponse inscrireDonneur(Long utilisateurId, Donneur donneur) {
        Utilisateur utilisateur = utilisateurRepository.findById(utilisateurId)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        if (donneurRepository.existsByCin(donneur.getCin())) {
            throw new RuntimeException("Ce CIN est déjà enregistré");
        }

        donneur.setUtilisateur(utilisateur);
        donneur.setEligible(verifierEligibilite(donneur));
        donneur = donneurRepository.save(donneur);

        return mapToResponse(donneur);
    }

    public DonneurResponse getDonneurByUtilisateurId(Long utilisateurId) {
        Donneur donneur = donneurRepository.findByUtilisateurId(utilisateurId)
                .orElseThrow(() -> new RuntimeException("Donneur non trouvé"));
        return mapToResponse(donneur);
    }

    public List<DonneurResponse> getTopDonneurs(int limit) {
        return donneurRepository.findTopDonneurs().stream()
                .limit(limit)
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<DonneurResponse> getDonneursEligibles() {
        return donneurRepository.findByEligibleTrue().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private boolean verifierEligibilite(Donneur donneur) {
        int age = Period.between(donneur.getDateNaissance(), LocalDate.now()).getYears();
        if (age < 18 || age > 65) return false;
        if (donneur.getPoids() < 50) return false;
        if (donneur.getDateDernierDon() != null) {
            LocalDate prochaineDate = donneur.getDateDernierDon().plusDays(90);
            if (LocalDate.now().isBefore(prochaineDate)) return false;
        }
        return true;
    }

    private DonneurResponse mapToResponse(Donneur donneur) {
        DonneurResponse response = new DonneurResponse();
        response.setId(donneur.getId());
        response.setUtilisateurId(donneur.getUtilisateur().getId());
        response.setNom(donneur.getUtilisateur().getNom());
        response.setPrenom(donneur.getUtilisateur().getPrenom());
        response.setEmail(donneur.getUtilisateur().getEmail());
        response.setCin(donneur.getCin());
        response.setDateNaissance(donneur.getDateNaissance());
        response.setGroupeSanguin(donneur.getGroupeSanguin());
        response.setSexe(donneur.getSexe());
        response.setAdresse(donneur.getAdresse());
        response.setVille(donneur.getVille());
        response.setTelephone(donneur.getUtilisateur().getTelephone());
        response.setEligible(donneur.getEligible());
        response.setDateDernierDon(donneur.getDateDernierDon());
        response.setNombreDonsTotal(donneur.getNombreDonsTotal());
        response.setDateProchaineEligibilite(donneur.getDateProchaineEligibilite());
        response.setPointsTotal(donneur.getUtilisateur().getPointsTotal());

        List<DonneurBadge> donneurBadges = donneurBadgeRepository.findByDonneurId(donneur.getId());
        response.setBadges(donneurBadges.stream().map(db -> {
            BadgeResponse br = new BadgeResponse();
            br.setId(db.getBadge().getId());
            br.setNom(db.getBadge().getNom());
            br.setDescription(db.getBadge().getDescription());
            br.setNiveau(db.getBadge().getNiveau());
            br.setIconeUrl(db.getBadge().getIconeUrl());
            br.setDateObtention(db.getDateObtention());
            br.setObtenu(true);
            return br;
        }).collect(Collectors.toList()));

        return response;
    }
}