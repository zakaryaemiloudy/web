package com.bks.service;

import com.bks.dto.*;
import com.bks.enums.PrioriteNotification;
import com.bks.enums.StatutDemande;
import com.bks.enums.TypeNotification;
import com.bks.model.*;
import com.bks.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DemandeSangService {

    @Autowired
    private DemandeSangRepository demandeRepository;

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    @Autowired
    private HopitalRepository hopitalRepository;

    @Autowired
    private StockService stockService;

    @Autowired
    private NotificationService notificationService;

    @Transactional
    public DemandeSangResponse creerDemande(Long patientId, DemandeSangRequest request) {
        Utilisateur patient = utilisateurRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient non trouvé"));

        Hopital hopital = hopitalRepository.findById(request.getHopitalId())
                .orElseThrow(() -> new RuntimeException("Hôpital non trouvé"));

        DemandeSang demande = new DemandeSang();
        demande.setPatient(patient);
        demande.setHopital(hopital);
        demande.setGroupeSanguinDemande(request.getGroupeSanguinDemande());
        demande.setQuantiteDemandee(request.getQuantiteDemandee());
        demande.setUrgence(request.getUrgence());
        demande.setNomPatient(request.getNomPatient());
        demande.setPrenomPatient(request.getPrenomPatient());
        demande.setDiagnostic(request.getDiagnostic());
        demande.setMedecinPrescripteur(request.getMedecinPrescripteur());
        demande.setDateBesoin(request.getDateBesoin());
        demande.setNotes(request.getNotes());
        demande.setStatut(StatutDemande.EN_ATTENTE);

        demande = demandeRepository.save(demande);

        notificationService.envoyerNotificationHopital(
                hopital.getId(),
                "Nouvelle demande de sang",
                "Une nouvelle demande de sang " + request.getGroupeSanguinDemande() + " a été reçue",
                TypeNotification.ALERTE,
                PrioriteNotification.HAUTE
        );

        return mapToResponse(demande);
    }

    public List<DemandeSangResponse> getDemandesParHopital(Long hopitalId) {
        return demandeRepository.findByHopitalId(hopitalId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<DemandeSangResponse> getDemandesUrgentes() {
        return demandeRepository.findDemandesUrgentes().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public DemandeSangResponse traiterDemande(Long demandeId, Long adminId, StatutDemande nouveauStatut) {
        DemandeSang demande = demandeRepository.findById(demandeId)
                .orElseThrow(() -> new RuntimeException("Demande non trouvée"));

        demande.setStatut(nouveauStatut);
        demande.setTraiteeParId(adminId);
        demande.setDateTraitement(LocalDateTime.now());

        if (nouveauStatut == StatutDemande.SATISFAITE) {
            stockService.deduireStock(
                    demande.getHopital().getId(),
                    demande.getGroupeSanguinDemande(),
                    demande.getQuantiteDemandee()
            );
        }

        demande = demandeRepository.save(demande);

        notificationService.envoyerNotificationUtilisateur(
                demande.getPatient().getId(),
                "Mise à jour de votre demande",
                "Votre demande de sang a été " + nouveauStatut.name().toLowerCase(),
                TypeNotification.INFO,
                PrioriteNotification.NORMALE
        );

        return mapToResponse(demande);
    }

    private DemandeSangResponse mapToResponse(DemandeSang demande) {
        DemandeSangResponse response = new DemandeSangResponse();
        response.setId(demande.getId());
        response.setPatientId(demande.getPatient().getId());
        response.setPatientEmail(demande.getPatient().getEmail());
        response.setHopitalId(demande.getHopital().getId());
        response.setHopitalNom(demande.getHopital().getNom());
        response.setGroupeSanguinDemande(demande.getGroupeSanguinDemande());
        response.setQuantiteDemandee(demande.getQuantiteDemandee());
        response.setDateDemande(demande.getDateDemande());
        response.setUrgence(demande.getUrgence());
        response.setStatut(demande.getStatut());
        response.setNomPatient(demande.getNomPatient());
        response.setPrenomPatient(demande.getPrenomPatient());
        response.setDiagnostic(demande.getDiagnostic());
        response.setMedecinPrescripteur(demande.getMedecinPrescripteur());
        response.setDateBesoin(demande.getDateBesoin());
        response.setNotes(demande.getNotes());
        response.setDateTraitement(demande.getDateTraitement());
        return response;
    }
}
