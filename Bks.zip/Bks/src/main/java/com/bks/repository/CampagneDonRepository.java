package com.bks.repository;

import com.bks.enums.StatutCampagne;
import com.bks.model.CampagneDon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CampagneDonRepository extends JpaRepository<CampagneDon, Long> {
    List<CampagneDon> findByStatut(StatutCampagne statut);
    List<CampagneDon> findByHopitalId(Long hopitalId);
    List<CampagneDon> findByNationaleTrueOrderByDateDebutDesc();
    List<CampagneDon> findByVilleOrRegion(String ville, String region);

    @Query("SELECT c FROM CampagneDon c WHERE c.dateDebut <= :now AND c.dateFin >= :now AND c.statut = com.bks.enums.StatutCampagne.EN_COURS")
    List<CampagneDon> findCampagnesActives(LocalDateTime now);
}
